#pragma once

#include "esp_brookesia.hpp"
#include "lvgl.h"
#include "UartService.hpp"

extern "C" void uart_ttl_ui_init(void);

/**
 * @class UARTTTL
 * @brief (中文注释) 串口助手App类，负责UI交互和生命周期管理。
 */
class UARTTTL : public ESP_Brookesia_PhoneApp {
public:
    UARTTTL();
    ~UARTTTL();

    // (中文注释) Brookesia框架调用的核心生命周期函数
    bool init(void) override;     // (中文注释) App安装时调用，用于一次性硬件初始化
    bool run(void) override;        // (中文注释) App每次启动时调用，用于创建UI
    bool back(void) override;       // (中文注释) 处理返回事件
    bool close(void) override;      // (中文注释) App退出(隐藏)时调用，用于清理UI资源
    bool resume(void) override;     // (中文注释) App从后台恢复时调用

private:
    void extraUiInit(void);
    static void uiUpdateTimerCb(lv_timer_t *timer);
    static void onButtonStartClicked(lv_event_t *e);
    static void onButtonStopClicked(lv_event_t *e);
    static void onButtonExitClicked(lv_event_t *e);

    // -- (中文注释) 成员变量 --
    UartService _uart_service;
    lv_timer_t* _update_timer;
    lv_obj_t*   _text_area_ttl;
    uint32_t    _last_tx_timestamp;
    size_t      _current_text_len; // (中文注释) 用于追踪TextArea文本长度，防止频繁调用strlen
};