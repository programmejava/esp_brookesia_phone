#include "UARTTTL.hpp"
#include "esp_log.h"
#include "ui/ui.h"
#include <string.h>

// --- (中文注释) 宏定义区 ---
#define MAX_UI_UPDATE_LEN 1024  // (中文注释) UI定时器单次聚合更新的最大字节数
#define TEXT_AREA_MAX_LEN 4096  // (中文注释) TextArea控件的最大文本长度，防止内存溢出
// ------------------------------

static const char *TAG = "AppUARTTTL"; // (中文注释) App的日志标签

// (中文注释) 构造函数
UARTTTL::UARTTTL() : 
    ESP_Brookesia_PhoneApp("UART TTL", nullptr, false),
    _update_timer(nullptr),
    _text_area_ttl(nullptr),
    _last_tx_timestamp(0),
    _current_text_len(0)
{
}

// (中文注释) 析构函数
UARTTTL::~UARTTTL()
{
}

// (中文注释) App的一次性初始化
bool UARTTTL::init(void)
{
    ESP_LOGI(TAG, "Initializing UART Service for the first time.");
    _uart_service.begin(115200);
    return true;
}

// (中文注释) App的UI入口
bool UARTTTL::run(void)
{
    uart_ttl_ui_init();
    extraUiInit();

    // (中文注释) 创建UI定时器，周期设为50ms，以保证较好的UI响应性
    _update_timer = lv_timer_create(uiUpdateTimerCb, 50, this);
    lv_timer_pause(_update_timer);

    const char* welcome_msg = "Welcome! Click START.\r\n";
    lv_textarea_set_text(_text_area_ttl, welcome_msg);
    _current_text_len = strlen(welcome_msg);
    return true;
}

// (中文注释) 处理返回键事件
bool UARTTTL::back(void)
{
    return notifyCoreClosed();
}

// (中文注释) 隐藏/关闭UI时的清理
bool UARTTTL::close(void)
{
    ESP_LOGI(TAG, "Hiding UI, stopping service temporarily.");
    if (_update_timer) {
        lv_timer_del(_update_timer);
        _update_timer = nullptr;
    }
    _uart_service.stopReceiving();
    _text_area_ttl = nullptr;
    return true;
}

// (中文注释) App从后台恢复
bool UARTTTL::resume(void)
{
    ESP_LOGI(TAG, "Resuming UI, resetting button states.");
    lv_obj_clear_state(ui_ButtonTTLStart, LV_STATE_DISABLED);
    lv_obj_add_state(ui_ButtonTTLStop, LV_STATE_DISABLED);
    return true;
}

// (中文注释) 绑定事件
void UARTTTL::extraUiInit(void)
{
    lv_obj_t* btn_start = ui_ButtonTTLStart;
    lv_obj_t* btn_stop = ui_ButtonTTLStop;
    lv_obj_t* btn_exit = ui_ButtonTTLExit;
    _text_area_ttl = ui_TextAreaTTL;

    lv_obj_add_event_cb(btn_start, onButtonStartClicked, LV_EVENT_CLICKED, this);
    lv_obj_add_event_cb(btn_stop, onButtonStopClicked, LV_EVENT_CLICKED, this);
    lv_obj_add_event_cb(btn_exit, onButtonExitClicked, LV_EVENT_CLICKED, this);

    lv_obj_clear_state(btn_start, LV_STATE_DISABLED);
    lv_obj_add_state(ui_ButtonTTLStop, LV_STATE_DISABLED);
}

// (中文注释) 最终优化的UI定时器回调函数
void UARTTTL::uiUpdateTimerCb(lv_timer_t *timer)
{
    UARTTTL* app = static_cast<UARTTTL*>(timer->user_data);
    if (!app || !app->_text_area_ttl) { return; }
    
    // (中文注释) 检查 Ring Buffer 中是否有数据
    if (app->_uart_service.available() > 0)
    {
        // (中文注释) 准备一个足够大的局部缓冲区来聚合将要显示的数据
        char local_buf[MAX_UI_UPDATE_LEN + 1];
        size_t total_read_len = 0;

        // (中文注释) **数据聚合**：在一个回调周期内，用while循环尽可能多地
        // (中文注释) 从Ring Buffer中读取数据，并暂存到local_buf中。
        while(app->_uart_service.available() > 0 && total_read_len < MAX_UI_UPDATE_LEN)
        {
            size_t len = app->_uart_service.read(
                (uint8_t*)local_buf + total_read_len,
                MAX_UI_UPDATE_LEN - total_read_len
            );
            
            if(len > 0) {
                total_read_len += len;
            } else {
                // (中文注释) Ring Buffer空了，退出聚合循环
                break;
            }
        }

        // (中文注释) 如果成功聚合了任何数据，则进行**唯一一次**的UI更新
        if (total_read_len > 0) {
            // (中文注释) 检查是否需要清空
            if (app->_current_text_len + total_read_len > TEXT_AREA_MAX_LEN) {
                const char* clear_msg = "[System] Log Cleared due to size limit.\r\n";
                lv_textarea_set_text(app->_text_area_ttl, clear_msg);
                app->_current_text_len = strlen(clear_msg);
            }
            
            // (中文注释) 确保字符串结尾，然后调用重量级的lv_textarea_add_text函数
            local_buf[total_read_len] = '\0';
            lv_textarea_add_text(app->_text_area_ttl, local_buf);
            
            // (中文注释) 更新我们自己的长度计数器
            app->_current_text_len += total_read_len;
        }
    }
    
    // (中文注释) 心跳发送逻辑保持不变
    if (lv_tick_elaps(app->_last_tx_timestamp) >= 2000) {
        const char* test_message = "Heartbeat TX...\r\n";
        app->_uart_service.write((const uint8_t*)test_message, strlen(test_message));
        app->_last_tx_timestamp = lv_tick_get();
    }
}

// (中文注释) “开始”按钮点击回调
void UARTTTL::onButtonStartClicked(lv_event_t* e)
{
    UARTTTL* app = static_cast<UARTTTL*>(lv_event_get_user_data(e));
    app->_uart_service.startReceiving();
    lv_timer_resume(app->_update_timer);
    app->_last_tx_timestamp = 0;

    const char* msg = "\r\n[System] Service Started.\r\n";
    lv_textarea_add_text(app->_text_area_ttl, msg);
    app->_current_text_len += strlen(msg);

    lv_obj_add_state(ui_ButtonTTLStart, LV_STATE_DISABLED);
    lv_obj_clear_state(ui_ButtonTTLStop, LV_STATE_DISABLED);
}

// (中文注释) “停止”按钮点击回调
void UARTTTL::onButtonStopClicked(lv_event_t *e)
{
    UARTTTL* app = static_cast<UARTTTL*>(lv_event_get_user_data(e));
    app->_uart_service.stopReceiving();
    lv_timer_pause(app->_update_timer);

    const char* msg = "\r\n[System] Service Stopped.\r\n";
    lv_textarea_add_text(app->_text_area_ttl, msg);
    app->_current_text_len += strlen(msg);

    lv_obj_clear_state(ui_ButtonTTLStart, LV_STATE_DISABLED);
    lv_obj_add_state(ui_ButtonTTLStop, LV_STATE_DISABLED);
}

// (中文注释) “退出”按钮点击回调
void UARTTTL::onButtonExitClicked(lv_event_t* e)
{
    UARTTTL* app = static_cast<UARTTTL*>(lv_event_get_user_data(e));
    app->notifyCoreClosed();
}