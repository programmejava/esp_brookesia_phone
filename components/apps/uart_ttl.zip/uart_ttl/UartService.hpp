#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/ringbuf.h"
#include "driver/uart.h"

// --- (中文注释) 硬件配置 ---
#define UART_SERVICE_PORT       (UART_NUM_1) // (中文注释) 使用 UART1
#define UART_SERVICE_TX_PIN     (29)         // (中文注释) TX 引脚
#define UART_SERVICE_RX_PIN     (30)         // (中文注释) RX 引脚
// ------------------------------------

// --- (中文注释) 缓冲区配置 ---
#define UART_DRIVER_BUF_SIZE    (4096)       // (中文注释) UART驱动的底层硬件缓冲区大小
#define RX_RING_BUFFER_SIZE     (4096)       // (中文注释) 上层软件环形缓冲区，用于UI和后台任务的安全数据交换
// ------------------------------------

/**
 * @class UartService
 * @brief (中文注释) 串口服务类，封装所有后台UART通信逻辑。
 *
 * (中文注释) 这是独立的业务逻辑层，与UI界面完全解耦。
 */
class UartService {
public:
    UartService();
    ~UartService();

    /**
     * @brief (中文注释) 初始化服务，配置硬件并启动后台任务。
     * @param baud_rate (中文注释) 通信波特率, 默认为 115200。
     */
    void begin(int baud_rate = 115200);

    /**
     * @brief (中文注释) 结束服务，释放所有资源。
     */
    void end();

    /**
     * @brief (中文注释) 开始接收数据。
     */
    void startReceiving();

    /**
     * @brief (中文注释) 停止接收数据。
     */
    void stopReceiving();

    /**
     * @brief (中文注释) 从内部环形缓冲区读取已接收的数据。
     * @param buffer (中文注释) 存放读取数据的目标缓冲区。
     * @param max_len (中文注释) 本次最多想读取的字节数。
     * @return (中文注释) 实际读取到的字节数。
     */
    size_t read(uint8_t *buffer, size_t max_len);

    /**
     * @brief (中文注释) 查询环形缓冲区中当前有多少字节的数据可供读取。
     * @return (中文注释) 可读取的字节数。
     */
    size_t available();

    /**
     * @brief (中文注释) 通过UART发送数据。
     * @param data (中文注释) 指向要发送数据的指针。
     * @param len (中文注释) 要发送的字节数。
     */
    void write(const uint8_t *data, size_t len);

private:
    /**
     * @brief (中文注释) 后台接收任务的静态函数实现。
     * @param arg (中文注释) 传递给任务的参数，这里是 UartService 类的实例指针。
     */
    static void uartRxTask(void* arg);
    
    RingbufHandle_t _rx_ring_buffer; // (中文注释) 指向环形缓冲区的句柄
    TaskHandle_t    _rx_task_handle; // (中文注释) 指向后台任务的句柄
    volatile bool   _is_running;     // (中文注释) 控制任务运行的标志位，volatile确保多线程可见性
};