#include "UartService.hpp"
#include "esp_log.h"
#include <string.h>

static const char* TAG = "UartService"; // (中文注释) 日志标签

// (中文注释) 构造函数：初始化成员变量
UartService::UartService() : 
    _rx_ring_buffer(nullptr),
    _rx_task_handle(nullptr),
    _is_running(false) 
{
}

// (中文注释) 析构函数：确保在对象销毁时调用end()来释放资源
UartService::~UartService()
{
    end();
}

// (中文注释) 初始化服务
void UartService::begin(int baud_rate)
{
    // (中文注释) 增加健壮性检查，先尝试删除可能残留的驱动
    uart_driver_delete(UART_SERVICE_PORT);
    
    // (中文注释) 1. 配置UART参数结构体
    uart_config_t uart_config = {
        .baud_rate = baud_rate,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    ESP_LOGI(TAG, "Initializing UART on port %d: TX=%d, RX=%d, Baud=%d", UART_SERVICE_PORT, UART_SERVICE_TX_PIN, UART_SERVICE_RX_PIN, baud_rate);
    
    // (中文注释) 2. 安装UART驱动
    ESP_ERROR_CHECK(uart_driver_install(UART_SERVICE_PORT, UART_DRIVER_BUF_SIZE, 0, 0, NULL, 0));
    // (中文注释) 3. 应用参数配置
    ESP_ERROR_CHECK(uart_param_config(UART_SERVICE_PORT, &uart_config));
    // (中文注释) 4. 设置引脚
    ESP_ERROR_CHECK(uart_set_pin(UART_SERVICE_PORT, UART_SERVICE_TX_PIN, UART_SERVICE_RX_PIN, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));

    // (中文注释) 5. 创建Ring Buffer
    _rx_ring_buffer = xRingbufferCreate(RX_RING_BUFFER_SIZE, RINGBUF_TYPE_BYTEBUF);
    if (_rx_ring_buffer == nullptr) {
        ESP_LOGE(TAG, "Failed to create Ring Buffer. Halting service initialization.");
        uart_driver_delete(UART_SERVICE_PORT);
        return;
    }

    _is_running = false;
    
    // (中文注释) 6. 创建后台任务，并提升优先级以确保及时处理硬件中断数据
    xTaskCreate(uartRxTask, "uart_rx_task", 4096, this, 10, &_rx_task_handle);
    if(_rx_task_handle == nullptr) {
         ESP_LOGE(TAG, "Failed to create UART RX task!");
    }
}

// (中文注释) 结束服务
void UartService::end()
{
    // (中文注释) 按顺序安全地释放资源
    if (_rx_task_handle) {
        vTaskDelete(_rx_task_handle);
        _rx_task_handle = nullptr;
    }
    if (_rx_ring_buffer) {
        vRingbufferDelete(_rx_ring_buffer);
        _rx_ring_buffer = nullptr;
    }
    uart_driver_delete(UART_SERVICE_PORT); // (中文注释) 最后卸载驱动
    _is_running = false;
    ESP_LOGI(TAG, "UART service has been shut down.");
}

// (中文注释) 开始接收
void UartService::startReceiving()
{
    _is_running = true;
}

// (中文注释) 停止接收
void UartService::stopReceiving()
{
    _is_running = false;
}

// (中文注释) 读取数据
size_t UartService::read(uint8_t *buffer, size_t max_len)
{
    if (!_rx_ring_buffer || max_len == 0) return 0;

    size_t item_size = 0;
    // (中文注释) 从Ring Buffer中接收数据项，设置为0超时（不等待）
    uint8_t *item = (uint8_t*)xRingbufferReceive(_rx_ring_buffer, &item_size, (TickType_t)0);

    if (item != nullptr) {
        // (中文注释) 计算实际要复制的长度，防止缓冲区溢出
        size_t copy_len = (max_len < item_size) ? max_len : item_size;
        memcpy(buffer, item, copy_len);
        // (中文注释) 重要：必须将数据项返还给Ring Buffer
        vRingbufferReturnItem(_rx_ring_buffer, (void*)item);
        return copy_len;
    }
    return 0; // (中文注释) 没有接收到数据项
}

// (中文注释) 检查可读数据
size_t UartService::available()
{
    if (!_rx_ring_buffer) return 0;
    // (中文注释) 通过总大小减去空闲大小来计算已用大小
    size_t free_size = xRingbufferGetCurFreeSize(_rx_ring_buffer);
    return RX_RING_BUFFER_SIZE - free_size;
}

// (中文注释) 写入数据
void UartService::write(const uint8_t *data, size_t len)
{
    if (len > 0) {
        uart_write_bytes(UART_SERVICE_PORT, (const char*)data, len);
    }
}

// (中文注释) 后台任务函数
void UartService::uartRxTask(void *arg)
{
    UartService* self = static_cast<UartService*>(arg);
    uint8_t* buffer = (uint8_t*)malloc(UART_DRIVER_BUF_SIZE);
    if (buffer == nullptr) {
        ESP_LOGE(TAG, "RX Task failed to allocate memory. Task exiting.");
        vTaskDelete(NULL);
        return;
    }

    ESP_LOGI(TAG, "UART RX task started successfully.");
    while (true) {
        if (self->_is_running) {
            // (中文注释) 从UART驱动读取数据，设置20ms短超时，提高响应性
            int rx_len = uart_read_bytes(UART_SERVICE_PORT, buffer, UART_DRIVER_BUF_SIZE, pdMS_TO_TICKS(20));
            if (rx_len > 0) {
                // (中文注释) 生产代码中移除了高频日志以保证性能
                
                // (中文注释) 使用0超时发送到Ring Buffer，如果满了就立即丢弃。
                // (中文注释) 这种策略是为了防止本高优先级任务被低速的UI层阻塞，
                // (中文注释) 优先确保能不断地从硬件驱动清空数据。
                if (xRingbufferSend(self->_rx_ring_buffer, buffer, rx_len, (TickType_t)0) != pdTRUE) {
                    // (中文注释) 这个日志很重要，当丢包发生时可以提供线索，予以保留
                    ESP_LOGW(TAG, "Ring buffer full, %d bytes dropped.", rx_len);
                }
            }
        } else {
            // (中文注释) 如果服务被暂停，则任务休眠一段时间以降低CPU占用
            vTaskDelay(pdMS_TO_TICKS(200));
        }
    }

    free(buffer);
    vTaskDelete(NULL);
}